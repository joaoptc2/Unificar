# Sistema de Gestão de RH Hospitalar

Sistema completo desenvolvido em PHP puro (Vanilla PHP 8.0+) com arquitetura MVC e MySQL, otimizado para rodar em hospedagens compartilhadas como Hostinger, cPanel, Locaweb, etc.

## Módulos Incluídos

1. **Gestão de Funcionários:** Cadastro completo com foto, dados pessoais, endereço e histórico.
2. **Ficha Funcional Digital:** Upload de documentos (RG, CPF, Contratos), atestados médicos (com CID e CRM) e histórico de ações.
3. **Controle de Vencimentos e Obrigações:** ASO, Exames Periódicos, Treinamentos e Validade de Conselho Regional (CRM, COREN).
4. **Agenda e Compromissos:** Calendário interativo para férias, plantões, treinamentos e reuniões.
5. **Aniversariantes do Mês:** Destaque automático no dashboard e listagem por mês/departamento.
6. **Dashboard Inteligente:** Métricas, alertas de vencimento, atalhos rápidos e gráficos.
7. **Processos Seletivos:** Gestão de vagas, página pública para candidatos e Kanban de recrutamento.
8. **Banco de Talentos:** Repositório de currículos de candidatos reprovados ou avulsos.
9. **Notificações:** Alertas no sistema sobre vencimentos, novos candidatos e aniversários.
10. **Gestão de Acessos e Auditoria:** Controle de perfis (Admin, RH, Gestor, Visualizador) e log de todas as ações.

## Requisitos do Servidor

- PHP 8.0 ou superior
- Extensões PHP: `pdo_mysql`, `mbstring`, `json`, `fileinfo`
- Servidor Web: Apache (com `mod_rewrite` habilitado) ou Nginx
- Banco de Dados: MySQL 5.7+ ou MariaDB 10.3+

## Guia de Instalação (Hostinger / cPanel)

O sistema foi desenhado para não depender de acesso SSH/Terminal. A instalação é feita via navegador.

### Passo 1: Preparar os arquivos
1. Faça o upload de todos os arquivos para a pasta raiz do seu domínio (ex: `public_html`).
2. Garanta que as pastas `config/` e `public/uploads/` tenham permissão de escrita (`CHMOD 755` ou `777`).

### Passo 2: Banco de Dados
1. No painel da sua hospedagem (Hostinger/cPanel), crie um novo Banco de Dados MySQL.
2. Crie um Usuário e associe-o ao banco com todos os privilégios.
3. Anote o Nome do Banco, Usuário e Senha.

### Passo 3: Assistente de Instalação
1. Acesse pelo navegador: `https://seudominio.com.br/install.php`
2. O sistema fará a verificação de requisitos. Clique em "Próximo".
3. Preencha os dados do Banco de Dados criados no Passo 2.
4. Crie a conta do Administrador (Nome, E-mail, Senha).
5. Defina o nome do Hospital/Clínica.
6. Clique em "Instalar Sistema".

### Passo 4: Pós-Instalação (MUITO IMPORTANTE)
1. Por motivos de segurança, **exclua o arquivo `install.php`** do seu servidor imediatamente após a instalação.
2. Acesse o sistema diretamente em: `https://seudominio.com.br/`
   O `index.php` na raiz funciona como bootstrap e redireciona automaticamente para o router principal.

## Configuração de Tarefas Automáticas (CRON Jobs)

Para que o sistema envie alertas de vencimentos e aniversários automaticamente, você precisa configurar os CRON Jobs no painel da sua hospedagem.

### No cPanel ou Hostinger:
1. Vá em **Avançado > Tarefas Cron (Cron Jobs)**.
2. Adicione as seguintes tarefas:

**Verificação de Vencimentos (Diariamente às 07:00)**
```bash
0 7 * * * php /home/seu_usuario/public_html/cron/check_expirations.php
```

**Verificação de Aniversariantes (Diariamente às 08:00)**
```bash
0 8 * * * php /home/seu_usuario/public_html/cron/check_birthdays.php
```

**Limpeza de Logs Antigos (Domingo às 03:00)**
```bash
0 3 * * 0 php /home/seu_usuario/public_html/cron/cleanup.php
```

*(Substitua `/home/seu_usuario/public_html/` pelo caminho absoluto correto da sua hospedagem).*

## Estrutura de Diretórios
- `/index.php` - Bootstrap que redireciona para o router principal
- `/install.php` - Assistente de instalação (excluir após instalar)
- `/.htaccess` - Regras de segurança e roteamento Apache
- `/app` - Contém Controllers, Views e Helpers (Regras de negócio)
- `/config` - Arquivos de configuração gerados pela instalação
- `/cron` - Scripts para tarefas automatizadas
- `/public` - Pasta pública (CSS, JS, Imagens, Uploads e router `index.php`)
- `/sql` - Arquivo de schema do banco de dados

## Segurança Implementada
- **Proteção CSRF:** Todos os formulários (POST) exigem token CSRF.
- **Prevenção SQL Injection:** Uso exclusivo de Prepared Statements (PDO).
- **Prevenção XSS:** Helper `Sanitize::e()` em todas as saídas de dados no HTML.
- **Senhas Seguras:** Hash `BCRYPT` com custo 12.
- **Proteção de Diretórios:** Arquivos `.htaccess` bloqueando listagem de diretórios e execução de scripts PHP na pasta de uploads.
- **Auditoria:** Registro de quem fez o quê e quando (tabela `audit_log`).
