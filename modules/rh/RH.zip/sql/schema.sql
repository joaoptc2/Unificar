-- ============================================================
-- RH Hospital - Schema SQL Completo
-- Sistema de Gestão de Recursos Humanos Hospitalar
-- Compatível com MySQL 5.7+ / MariaDB 10.3+
-- ============================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ------------------------------------------------------------
-- Tabela: departments (Departamentos/Setores)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `departments` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(150) NOT NULL,
    `description` TEXT NULL,
    `active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_department_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: job_positions (Cargos)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `job_positions` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(150) NOT NULL,
    `department_id` INT UNSIGNED NULL,
    `description` TEXT NULL,
    `active` TINYINT(1) NOT NULL DEFAULT 1,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_position_dept` (`department_id`),
    CONSTRAINT `fk_position_dept` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: users (Utilizadores do sistema)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name` VARCHAR(200) NOT NULL,
    `email` VARCHAR(200) NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role` ENUM('admin','rh','gestor','visualizador') NOT NULL DEFAULT 'visualizador',
    `department_id` INT UNSIGNED NULL,
    `active` TINYINT(1) NOT NULL DEFAULT 1,
    `last_login` DATETIME NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_user_email` (`email`),
    KEY `idx_user_role` (`role`),
    CONSTRAINT `fk_user_dept` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: employees (Funcionários)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `employees` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `full_name` VARCHAR(200) NOT NULL,
    `cpf` VARCHAR(14) NOT NULL,
    `birth_date` DATE NOT NULL,
    `gender` ENUM('M','F','O') NOT NULL,
    `phone` VARCHAR(20) NULL,
    `email` VARCHAR(200) NULL,
    `address_street` VARCHAR(255) NULL,
    `address_number` VARCHAR(20) NULL,
    `address_complement` VARCHAR(100) NULL,
    `address_neighborhood` VARCHAR(100) NULL,
    `address_city` VARCHAR(100) NULL,
    `address_state` VARCHAR(2) NULL,
    `address_zip` VARCHAR(10) NULL,
    `job_position_id` INT UNSIGNED NULL,
    `department_id` INT UNSIGNED NULL,
    `admission_date` DATE NOT NULL,
    `contract_type` ENUM('CLT','PJ','Temporario','Estagio','Terceirizado') NOT NULL DEFAULT 'CLT',
    `status` ENUM('ativo','afastado','desligado') NOT NULL DEFAULT 'ativo',
    `termination_date` DATE NULL,
    `leave_date` DATE NULL,
    `return_date` DATE NULL,
    `regional_council` VARCHAR(50) NULL,
    `council_number` VARCHAR(50) NULL,
    `council_expiry` DATE NULL,
    `photo` VARCHAR(255) NULL,
    `notes` TEXT NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_employee_cpf` (`cpf`),
    KEY `idx_employee_name` (`full_name`),
    KEY `idx_employee_status` (`status`),
    KEY `idx_employee_dept` (`department_id`),
    KEY `idx_employee_position` (`job_position_id`),
    KEY `idx_employee_admission` (`admission_date`),
    CONSTRAINT `fk_employee_position` FOREIGN KEY (`job_position_id`) REFERENCES `job_positions`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_employee_dept` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_employee_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: employee_documents (Documentos do funcionário)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `employee_documents` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id` INT UNSIGNED NOT NULL,
    `doc_type` ENUM('RG','CPF','Contrato','Certificado','Atestado','Outro') NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `file_path` VARCHAR(500) NOT NULL,
    `file_original_name` VARCHAR(255) NULL,
    `file_size` INT UNSIGNED NULL,
    `notes` TEXT NULL,
    `uploaded_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_doc_employee` (`employee_id`),
    KEY `idx_doc_type` (`doc_type`),
    CONSTRAINT `fk_doc_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_doc_uploader` FOREIGN KEY (`uploaded_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: employee_records (Histórico / Ficha Funcional)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `employee_records` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id` INT UNSIGNED NOT NULL,
    `record_type` ENUM('admissao','promocao','transferencia','afastamento','retorno','desligamento','alteracao','observacao') NOT NULL,
    `description` TEXT NOT NULL,
    `old_value` TEXT NULL,
    `new_value` TEXT NULL,
    `record_date` DATE NOT NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_record_employee` (`employee_id`),
    KEY `idx_record_type` (`record_type`),
    KEY `idx_record_date` (`record_date`),
    CONSTRAINT `fk_record_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_record_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: medical_certificates (Atestados médicos)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `medical_certificates` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id` INT UNSIGNED NOT NULL,
    `issue_date` DATE NOT NULL,
    `days` INT UNSIGNED NOT NULL DEFAULT 1,
    `cid` VARCHAR(20) NULL,
    `doctor_name` VARCHAR(200) NULL,
    `doctor_crm` VARCHAR(50) NULL,
    `notes` TEXT NULL,
    `file_path` VARCHAR(500) NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_cert_employee` (`employee_id`),
    KEY `idx_cert_date` (`issue_date`),
    CONSTRAINT `fk_cert_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_cert_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: expirations (Vencimentos e Obrigações)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expirations` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id` INT UNSIGNED NOT NULL,
    `type` ENUM('exame_periodico','aso_admissional','aso_demissional','aso_periodico','certificacao','treinamento','conselho_regional','outro') NOT NULL,
    `title` VARCHAR(200) NOT NULL,
    `description` TEXT NULL,
    `issue_date` DATE NULL,
    `expiry_date` DATE NOT NULL,
    `status` ENUM('valido','proximo_vencimento','vencido') NOT NULL DEFAULT 'valido',
    `alert_days` INT UNSIGNED NOT NULL DEFAULT 30,
    `file_path` VARCHAR(500) NULL,
    `renewed` TINYINT(1) NOT NULL DEFAULT 0,
    `notified_at` DATETIME NULL,
    `notified_expired_at` DATETIME NULL,
    `created_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_exp_employee` (`employee_id`),
    KEY `idx_exp_type` (`type`),
    KEY `idx_exp_expiry` (`expiry_date`),
    KEY `idx_exp_status` (`status`),
    CONSTRAINT `fk_exp_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_exp_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: expiration_history (Histórico de renovações)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `expiration_history` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `expiration_id` INT UNSIGNED NOT NULL,
    `old_expiry_date` DATE NOT NULL,
    `new_expiry_date` DATE NOT NULL,
    `notes` TEXT NULL,
    `renewed_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_exphist_exp` (`expiration_id`),
    CONSTRAINT `fk_exphist_exp` FOREIGN KEY (`expiration_id`) REFERENCES `expirations`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_exphist_user` FOREIGN KEY (`renewed_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: schedules (Agenda e Compromissos)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `schedules` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `employee_id` INT UNSIGNED NULL,
    `title` VARCHAR(200) NOT NULL,
    `description` TEXT NULL,
    `event_date` DATE NOT NULL,
    `event_time` TIME NULL,
    `end_time` TIME NULL,
    `event_type` ENUM('compromisso','vencimento','reuniao','treinamento','outro') NOT NULL DEFAULT 'compromisso',
    `expiration_id` INT UNSIGNED NULL,
    `color` VARCHAR(7) NULL DEFAULT '#0d6efd',
    `created_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_sched_date` (`event_date`),
    KEY `idx_sched_employee` (`employee_id`),
    CONSTRAINT `fk_sched_employee` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_sched_expiration` FOREIGN KEY (`expiration_id`) REFERENCES `expirations`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_sched_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: recruitment_jobs (Vagas de Processos Seletivos)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `recruitment_jobs` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title` VARCHAR(200) NOT NULL,
    `description` TEXT NULL,
    `requirements` TEXT NULL,
    `department_id` INT UNSIGNED NULL,
    `status` ENUM('aberta','fechada') NOT NULL DEFAULT 'aberta',
    `created_by` INT UNSIGNED NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_job_status` (`status`),
    CONSTRAINT `fk_job_dept` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_job_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: recruitment_steps (Etapas do Processo Seletivo)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `recruitment_steps` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `job_id` INT UNSIGNED NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `step_order` INT UNSIGNED NOT NULL DEFAULT 1,
    `description` TEXT NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_step_job` (`job_id`),
    CONSTRAINT `fk_step_job` FOREIGN KEY (`job_id`) REFERENCES `recruitment_jobs`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: candidates (Candidatos)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `candidates` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `job_id` INT UNSIGNED NULL,
    `full_name` VARCHAR(200) NOT NULL,
    `email` VARCHAR(200) NOT NULL,
    `phone` VARCHAR(20) NULL,
    `cpf` VARCHAR(14) NULL,
    `area` VARCHAR(100) NULL,
    `experience` TEXT NULL,
    `resume_path` VARCHAR(500) NULL,
    `current_step_id` INT UNSIGNED NULL,
    `status` ENUM('inscrito','em_andamento','aprovado','reprovado','banco_talentos') NOT NULL DEFAULT 'inscrito',
    `notes` TEXT NULL,
    `access_token` VARCHAR(64) NULL,
    `in_talent_pool` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY `idx_cand_job` (`job_id`),
    KEY `idx_cand_status` (`status`),
    KEY `idx_cand_talent` (`in_talent_pool`),
    KEY `idx_cand_token` (`access_token`),
    CONSTRAINT `fk_cand_job` FOREIGN KEY (`job_id`) REFERENCES `recruitment_jobs`(`id`) ON DELETE SET NULL,
    CONSTRAINT `fk_cand_step` FOREIGN KEY (`current_step_id`) REFERENCES `recruitment_steps`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: candidate_progress (Progresso do candidato nas etapas)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `candidate_progress` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `candidate_id` INT UNSIGNED NOT NULL,
    `step_id` INT UNSIGNED NOT NULL,
    `status` ENUM('pendente','aprovado','reprovado') NOT NULL DEFAULT 'pendente',
    `notes` TEXT NULL,
    `evaluated_by` INT UNSIGNED NULL,
    `evaluated_at` DATETIME NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_progress_cand` (`candidate_id`),
    KEY `idx_progress_step` (`step_id`),
    CONSTRAINT `fk_progress_cand` FOREIGN KEY (`candidate_id`) REFERENCES `candidates`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_progress_step` FOREIGN KEY (`step_id`) REFERENCES `recruitment_steps`(`id`) ON DELETE CASCADE,
    CONSTRAINT `fk_progress_eval` FOREIGN KEY (`evaluated_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: notifications (Notificações)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `notifications` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NULL,
    `title` VARCHAR(200) NOT NULL,
    `message` TEXT NOT NULL,
    `type` VARCHAR(50) NOT NULL DEFAULT 'info',
    `link` VARCHAR(500) NULL,
    `reference_type` VARCHAR(50) NULL,
    `reference_id` INT UNSIGNED NULL,
    `is_read` TINYINT(1) NOT NULL DEFAULT 0,
    `read_at` DATETIME NULL,
    `sent_email` TINYINT(1) NOT NULL DEFAULT 0,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_notif_user` (`user_id`),
    KEY `idx_notif_read` (`is_read`),
    KEY `idx_notif_type` (`type`),
    CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: audit_log (Log de Auditoria)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_log` (
    `id` BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `user_id` INT UNSIGNED NULL,
    `action` VARCHAR(100) NOT NULL,
    `table_name` VARCHAR(100) NULL,
    `record_id` INT UNSIGNED NULL,
    `old_data` JSON NULL,
    `new_data` JSON NULL,
    `ip_address` VARCHAR(45) NULL,
    `user_agent` VARCHAR(500) NULL,
    `created_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY `idx_audit_user` (`user_id`),
    KEY `idx_audit_action` (`action`),
    KEY `idx_audit_table` (`table_name`),
    KEY `idx_audit_date` (`created_at`),
    CONSTRAINT `fk_audit_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Tabela: settings (Configurações do sistema)
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
    `id` INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `setting_key` VARCHAR(100) NOT NULL,
    `setting_value` TEXT NULL,
    `description` VARCHAR(255) NULL,
    `updated_at` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uk_setting_key` (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ------------------------------------------------------------
-- Dados iniciais: Configurações padrão
-- ------------------------------------------------------------
INSERT INTO `settings` (`setting_key`, `setting_value`, `description`) VALUES
('hospital_name', 'Hospital Central', 'Nome do hospital'),
('system_email', 'rh@hospital.com.br', 'E-mail do sistema para envio de notificações'),
('upload_max_size', '5242880', 'Tamanho máximo de upload em bytes (5MB)'),
('expiry_alert_days', '30', 'Dias de antecedência para alertas de vencimento'),
('items_per_page', '20', 'Itens por página na listagem');

SET FOREIGN_KEY_CHECKS = 1;
