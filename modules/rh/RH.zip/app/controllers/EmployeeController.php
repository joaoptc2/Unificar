<?php
/**
 * Controller de Funcionários (Módulo 1 — Gestão de Funcionários)
 */
class EmployeeController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Listagem com busca e filtros avançados
     */
    public function index(): void
    {
        Auth::requirePermission('employees', 'view');

        $search     = Sanitize::get('search');
        $status     = Sanitize::get('status');
        $department = Sanitize::int($_GET['department'] ?? 0);
        $contract   = Sanitize::get('contract');
        $currentPage = max(1, Sanitize::int($_GET['p'] ?? 1));

        // Construir query
        $where = [];
        $params = [];

        if ($search) {
            $where[] = '(e.full_name LIKE ? OR e.cpf LIKE ? OR e.email LIKE ?)';
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
            $params[] = "%{$search}%";
        }
        if ($status) {
            $where[] = 'e.status = ?';
            $params[] = $status;
        }
        if ($department) {
            $where[] = 'e.department_id = ?';
            $params[] = $department;
        }
        if ($contract) {
            $where[] = 'e.contract_type = ?';
            $params[] = $contract;
        }

        $whereClause = $where ? 'WHERE ' . implode(' AND ', $where) : '';

        // Contar total
        $countStmt = $this->db->prepare("SELECT COUNT(*) FROM employees e {$whereClause}");
        $countStmt->execute($params);
        $total = (int)$countStmt->fetchColumn();

        $pagination = new Pagination($total, $currentPage);

        // Buscar dados
        $sql = "SELECT e.*, d.name as department_name, j.title as position_title
                FROM employees e
                LEFT JOIN departments d ON e.department_id = d.id
                LEFT JOIN job_positions j ON e.job_position_id = j.id
                {$whereClause}
                ORDER BY e.full_name ASC
                LIMIT {$pagination->perPage} OFFSET {$pagination->offset}";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $employees = $stmt->fetchAll();

        // Departamentos para filtro
        $departments = $this->db->query('SELECT id, name FROM departments WHERE active = 1 ORDER BY name')->fetchAll();

        $pageTitle = 'Funcionários';
        $page = 'employees';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/employees/index.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    /**
     * Formulário de criação
     */
    public function create(): void
    {
        Auth::requirePermission('employees', 'create');

        $departments = $this->db->query('SELECT id, name FROM departments WHERE active = 1 ORDER BY name')->fetchAll();
        $positions = $this->db->query('SELECT id, title FROM job_positions WHERE active = 1 ORDER BY title')->fetchAll();
        $employee = null;

        $pageTitle = 'Novo Funcionário';
        $page = 'employees';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/employees/form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    /**
     * Salvar novo funcionário
     */
    public function store(): void
    {
        Auth::requirePermission('employees', 'create');
        Csrf::check();

        $data = $this->getFormData();
        $errors = $this->validate($data);

        if (!empty($errors)) {
            Session::flash('error', implode('<br>', $errors));
            header('Location: index.php?page=employees&action=create');
            exit;
        }

        // Upload de foto
        $photoPath = null;
        if (!empty($_FILES['photo']['name'])) {
            $upload = Upload::handle('photo', 'employees');
            if ($upload['success']) {
                $photoPath = $upload['path'];
            }
        }

        $stmt = $this->db->prepare(
            'INSERT INTO employees (full_name, cpf, birth_date, gender, phone, email,
                address_street, address_number, address_complement, address_neighborhood,
                address_city, address_state, address_zip, job_position_id, department_id,
                admission_date, contract_type, status, termination_date, leave_date, return_date,
                regional_council, council_number, council_expiry, photo, notes, created_by)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)'
        );
        $stmt->execute([
            $data['full_name'], $data['cpf'], $data['birth_date'], $data['gender'],
            $data['phone'], $data['email'], $data['address_street'], $data['address_number'],
            $data['address_complement'], $data['address_neighborhood'], $data['address_city'],
            $data['address_state'], $data['address_zip'],
            $data['job_position_id'] ?: null, $data['department_id'] ?: null,
            $data['admission_date'], $data['contract_type'], $data['status'],
            $data['termination_date'] ?: null, $data['leave_date'] ?: null, $data['return_date'] ?: null,
            $data['regional_council'], $data['council_number'], $data['council_expiry'] ?: null,
            $photoPath, $data['notes'], Session::userId()
        ]);

        $employeeId = (int)$this->db->lastInsertId();

        // Registrar no histórico
        $this->addRecord($employeeId, 'admissao', 'Funcionário cadastrado no sistema', $data['admission_date']);

        AuditLog::log('create', 'employees', $employeeId, null, $data);

        Session::flash('success', 'Funcionário cadastrado com sucesso.');
        header('Location: index.php?page=employees&action=show&id=' . $employeeId);
        exit;
    }

    /**
     * Visualizar funcionário (Ficha Funcional)
     */
    public function show(): void
    {
        Auth::requirePermission('employees', 'view');

        $id = Sanitize::int($_GET['id'] ?? 0);
        $employee = $this->getEmployee($id);

        if (!$employee) {
            Session::flash('error', 'Funcionário não encontrado.');
            header('Location: index.php?page=employees');
            exit;
        }

        // Documentos
        $stmt = $this->db->prepare('SELECT * FROM employee_documents WHERE employee_id = ? ORDER BY created_at DESC');
        $stmt->execute([$id]);
        $documents = $stmt->fetchAll();

        // Histórico
        $stmt = $this->db->prepare(
            'SELECT r.*, u.name as user_name FROM employee_records r
             LEFT JOIN users u ON r.created_by = u.id
             WHERE r.employee_id = ? ORDER BY r.record_date DESC, r.created_at DESC'
        );
        $stmt->execute([$id]);
        $records = $stmt->fetchAll();

        // Vencimentos
        $stmt = $this->db->prepare('SELECT * FROM expirations WHERE employee_id = ? ORDER BY expiry_date ASC');
        $stmt->execute([$id]);
        $expirations = $stmt->fetchAll();

        // Atestados
        $stmt = $this->db->prepare('SELECT * FROM medical_certificates WHERE employee_id = ? ORDER BY issue_date DESC');
        $stmt->execute([$id]);
        $certificates = $stmt->fetchAll();

        $pageTitle = $employee['full_name'];
        $page = 'employees';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/employees/show.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    /**
     * Formulário de edição
     */
    public function edit(): void
    {
        Auth::requirePermission('employees', 'edit');

        $id = Sanitize::int($_GET['id'] ?? 0);
        $employee = $this->getEmployee($id);

        if (!$employee) {
            Session::flash('error', 'Funcionário não encontrado.');
            header('Location: index.php?page=employees');
            exit;
        }

        $departments = $this->db->query('SELECT id, name FROM departments WHERE active = 1 ORDER BY name')->fetchAll();
        $positions = $this->db->query('SELECT id, title FROM job_positions WHERE active = 1 ORDER BY title')->fetchAll();

        $pageTitle = 'Editar Funcionário';
        $page = 'employees';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/employees/form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    /**
     * Atualizar funcionário
     */
    public function update(): void
    {
        Auth::requirePermission('employees', 'edit');
        Csrf::check();

        $id = Sanitize::int($_POST['id'] ?? 0);
        $old = $this->getEmployee($id);

        if (!$old) {
            Session::flash('error', 'Funcionário não encontrado.');
            header('Location: index.php?page=employees');
            exit;
        }

        $data = $this->getFormData();
        $errors = $this->validate($data, $id);

        if (!empty($errors)) {
            Session::flash('error', implode('<br>', $errors));
            header('Location: index.php?page=employees&action=edit&id=' . $id);
            exit;
        }

        // Upload de foto
        $photoPath = $old['photo'];
        if (!empty($_FILES['photo']['name'])) {
            $upload = Upload::handle('photo', 'employees');
            if ($upload['success']) {
                // Remover foto antiga
                if ($old['photo']) Upload::delete($old['photo']);
                $photoPath = $upload['path'];
            }
        }

        $stmt = $this->db->prepare(
            'UPDATE employees SET full_name=?, cpf=?, birth_date=?, gender=?, phone=?, email=?,
                address_street=?, address_number=?, address_complement=?, address_neighborhood=?,
                address_city=?, address_state=?, address_zip=?, job_position_id=?, department_id=?,
                admission_date=?, contract_type=?, status=?, termination_date=?, leave_date=?, return_date=?,
                regional_council=?, council_number=?, council_expiry=?, photo=?, notes=?
             WHERE id=?'
        );
        $stmt->execute([
            $data['full_name'], $data['cpf'], $data['birth_date'], $data['gender'],
            $data['phone'], $data['email'], $data['address_street'], $data['address_number'],
            $data['address_complement'], $data['address_neighborhood'], $data['address_city'],
            $data['address_state'], $data['address_zip'],
            $data['job_position_id'] ?: null, $data['department_id'] ?: null,
            $data['admission_date'], $data['contract_type'], $data['status'],
            $data['termination_date'] ?: null, $data['leave_date'] ?: null, $data['return_date'] ?: null,
            $data['regional_council'], $data['council_number'], $data['council_expiry'] ?: null,
            $photoPath, $data['notes'], $id
        ]);

        // Registrar alterações no histórico
        $changes = $this->detectChanges($old, $data);
        if ($changes) {
            $this->addRecord($id, 'alteracao', $changes, date('Y-m-d'));
        }

        // Registrar mudança de status
        if ($old['status'] !== $data['status']) {
            $recordType = match($data['status']) {
                'afastado' => 'afastamento',
                'desligado' => 'desligamento',
                'ativo' => 'retorno',
                default => 'alteracao'
            };
            $this->addRecord($id, $recordType,
                'Status alterado de ' . $old['status'] . ' para ' . $data['status'],
                date('Y-m-d')
            );
        }

        AuditLog::log('update', 'employees', $id, $old, $data);

        Session::flash('success', 'Funcionário atualizado com sucesso.');
        header('Location: index.php?page=employees&action=show&id=' . $id);
        exit;
    }

    /**
     * Excluir funcionário
     */
    public function delete(): void
    {
        Auth::requirePermission('employees', 'delete');
        Csrf::check();

        $id = Sanitize::int($_POST['id'] ?? 0);
        $employee = $this->getEmployee($id);

        if ($employee) {
            if ($employee['photo']) Upload::delete($employee['photo']);
            $stmt = $this->db->prepare('DELETE FROM employees WHERE id = ?');
            $stmt->execute([$id]);
            AuditLog::log('delete', 'employees', $id, $employee);
            Session::flash('success', 'Funcionário excluído com sucesso.');
        }

        header('Location: index.php?page=employees');
        exit;
    }

    /**
     * Exportar funcionários para CSV
     */
    public function export(): void
    {
        Auth::requirePermission('employees', 'export');

        $status = Sanitize::get('status');
        $where = $status ? 'WHERE e.status = ?' : '';
        $params = $status ? [$status] : [];

        $sql = "SELECT e.*, d.name as department_name, j.title as position_title
                FROM employees e
                LEFT JOIN departments d ON e.department_id = d.id
                LEFT JOIN job_positions j ON e.job_position_id = j.id
                {$where}
                ORDER BY e.full_name";
        $stmt = $this->db->prepare($sql);
        $stmt->execute($params);
        $employees = $stmt->fetchAll();

        $headers = ['Nome', 'CPF', 'Nascimento', 'Sexo', 'Telefone', 'E-mail',
                     'Cargo', 'Departamento', 'Admissão', 'Contrato', 'Status'];
        $rows = [];
        foreach ($employees as $e) {
            $rows[] = [
                $e['full_name'],
                Sanitize::formatCpf($e['cpf']),
                Sanitize::formatDate($e['birth_date']),
                $e['gender'],
                $e['phone'],
                $e['email'],
                $e['position_title'] ?? '-',
                $e['department_name'] ?? '-',
                Sanitize::formatDate($e['admission_date']),
                $e['contract_type'],
                $e['status'],
            ];
        }

        AuditLog::log('export', 'employees');
        Export::csv('funcionarios_' . date('Y-m-d') . '.csv', $headers, $rows);
    }

    // ---- Métodos auxiliares ----

    private function getEmployee(int $id): ?array
    {
        $stmt = $this->db->prepare(
            'SELECT e.*, d.name as department_name, j.title as position_title
             FROM employees e
             LEFT JOIN departments d ON e.department_id = d.id
             LEFT JOIN job_positions j ON e.job_position_id = j.id
             WHERE e.id = ?'
        );
        $stmt->execute([$id]);
        return $stmt->fetch() ?: null;
    }

    private function getFormData(): array
    {
        return [
            'full_name'            => Sanitize::post('full_name'),
            'cpf'                  => Sanitize::cpf($_POST['cpf'] ?? ''),
            'birth_date'           => Sanitize::date($_POST['birth_date'] ?? ''),
            'gender'               => Sanitize::post('gender'),
            'phone'                => Sanitize::phone($_POST['phone'] ?? ''),
            'email'                => Sanitize::email($_POST['email'] ?? ''),
            'address_street'       => Sanitize::post('address_street'),
            'address_number'       => Sanitize::post('address_number'),
            'address_complement'   => Sanitize::post('address_complement'),
            'address_neighborhood' => Sanitize::post('address_neighborhood'),
            'address_city'         => Sanitize::post('address_city'),
            'address_state'        => Sanitize::post('address_state'),
            'address_zip'          => Sanitize::post('address_zip'),
            'job_position_id'      => Sanitize::int($_POST['job_position_id'] ?? 0),
            'department_id'        => Sanitize::int($_POST['department_id'] ?? 0),
            'admission_date'       => Sanitize::date($_POST['admission_date'] ?? ''),
            'contract_type'        => Sanitize::post('contract_type'),
            'status'               => Sanitize::post('status'),
            'termination_date'     => Sanitize::date($_POST['termination_date'] ?? ''),
            'leave_date'           => Sanitize::date($_POST['leave_date'] ?? ''),
            'return_date'          => Sanitize::date($_POST['return_date'] ?? ''),
            'regional_council'     => Sanitize::post('regional_council'),
            'council_number'       => Sanitize::post('council_number'),
            'council_expiry'       => Sanitize::date($_POST['council_expiry'] ?? ''),
            'notes'                => Sanitize::post('notes'),
        ];
    }

    private function validate(array $data, int $excludeId = 0): array
    {
        $errors = [];
        if (empty($data['full_name'])) $errors[] = 'Nome completo é obrigatório.';
        if (empty($data['cpf'])) $errors[] = 'CPF é obrigatório.';
        elseif (!Sanitize::isValidCpf($data['cpf'])) $errors[] = 'CPF inválido.';
        if (empty($data['birth_date'])) $errors[] = 'Data de nascimento é obrigatória.';
        if (empty($data['gender'])) $errors[] = 'Sexo é obrigatório.';
        if (empty($data['admission_date'])) $errors[] = 'Data de admissão é obrigatória.';

        // Verificar CPF duplicado
        if (!empty($data['cpf'])) {
            $sql = 'SELECT id FROM employees WHERE cpf = ?';
            $params = [$data['cpf']];
            if ($excludeId) {
                $sql .= ' AND id != ?';
                $params[] = $excludeId;
            }
            $stmt = $this->db->prepare($sql);
            $stmt->execute($params);
            if ($stmt->fetch()) {
                $errors[] = 'Já existe um funcionário com este CPF.';
            }
        }

        return $errors;
    }

    private function addRecord(int $employeeId, string $type, string $description, string $date): void
    {
        $stmt = $this->db->prepare(
            'INSERT INTO employee_records (employee_id, record_type, description, record_date, created_by)
             VALUES (?, ?, ?, ?, ?)'
        );
        $stmt->execute([$employeeId, $type, $description, $date, Session::userId()]);
    }

    private function detectChanges(array $old, array $new): string
    {
        $labels = [
            'full_name' => 'Nome', 'cpf' => 'CPF', 'phone' => 'Telefone',
            'email' => 'E-mail', 'contract_type' => 'Contrato', 'status' => 'Status',
            'department_id' => 'Departamento', 'job_position_id' => 'Cargo',
        ];
        $changes = [];
        foreach ($labels as $field => $label) {
            $oldVal = $old[$field] ?? '';
            $newVal = $new[$field] ?? '';
            if ((string)$oldVal !== (string)$newVal) {
                $changes[] = "{$label}: {$oldVal} → {$newVal}";
            }
        }
        return implode('; ', $changes);
    }
}
