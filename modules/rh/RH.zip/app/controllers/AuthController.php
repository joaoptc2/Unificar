<?php
/**
 * Controller de Autenticação
 */
class AuthController
{
    public function index(): void
    {
        if (Session::isLoggedIn()) {
            header('Location: index.php?page=dashboard');
            exit;
        }
        $error = Session::flash('error');
        $success = Session::flash('success');
        require __DIR__ . '/../views/auth/login.php';
    }

    public function login(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?page=login');
            exit;
        }

        Csrf::check();

        $email    = Sanitize::email($_POST['email'] ?? '');
        $password = $_POST['password'] ?? '';

        if (empty($email) || empty($password)) {
            Session::flash('error', 'Preencha todos os campos.');
            header('Location: index.php?page=login');
            exit;
        }

        if (Auth::attempt($email, $password)) {
            header('Location: index.php?page=dashboard');
            exit;
        }

        Session::flash('error', 'E-mail ou senha incorretos.');
        header('Location: index.php?page=login');
        exit;
    }

    public function logout(): void
    {
        Auth::logout();
        Session::start();
        Session::flash('success', 'Sessão encerrada com sucesso.');
        header('Location: index.php?page=login');
        exit;
    }
}
