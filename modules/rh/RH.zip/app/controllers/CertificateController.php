<?php
/**
 * Controller de Atestados Médicos
 */
class CertificateController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        header('Location: index.php?page=employees');
        exit;
    }

    public function create(): void
    {
        Auth::requirePermission('certificates', 'create');
        $employeeId = Sanitize::int($_GET['employee_id'] ?? 0);

        $stmt = $this->db->prepare('SELECT id, full_name FROM employees WHERE id = ?');
        $stmt->execute([$employeeId]);
        $employee = $stmt->fetch();

        if (!$employee) {
            Session::flash('error', 'Funcionário não encontrado.');
            header('Location: index.php?page=employees');
            exit;
        }

        $pageTitle = 'Novo Atestado';
        $page = 'employees';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/employees/certificate_form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function store(): void
    {
        Auth::requirePermission('certificates', 'create');
        Csrf::check();

        $employeeId = Sanitize::int($_POST['employee_id'] ?? 0);
        $issueDate  = Sanitize::date($_POST['issue_date'] ?? '');
        $days       = Sanitize::int($_POST['days'] ?? 1);
        $cid        = Sanitize::post('cid');
        $doctorName = Sanitize::post('doctor_name');
        $doctorCrm  = Sanitize::post('doctor_crm');
        $notes      = Sanitize::post('notes');

        if (!$employeeId || !$issueDate) {
            Session::flash('error', 'Preencha os campos obrigatórios.');
            header('Location: index.php?page=certificates&action=create&employee_id=' . $employeeId);
            exit;
        }

        $filePath = null;
        if (!empty($_FILES['file']['name'])) {
            $upload = Upload::handle('file', 'documents');
            if ($upload['success']) $filePath = $upload['path'];
        }

        $stmt = $this->db->prepare(
            'INSERT INTO medical_certificates (employee_id, issue_date, days, cid, doctor_name, doctor_crm, notes, file_path, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([$employeeId, $issueDate, $days, $cid, $doctorName, $doctorCrm, $notes, $filePath, Session::userId()]);

        AuditLog::log('create', 'medical_certificates', (int)$this->db->lastInsertId());

        Session::flash('success', 'Atestado cadastrado com sucesso.');
        header('Location: index.php?page=employees&action=show&id=' . $employeeId);
        exit;
    }
}
