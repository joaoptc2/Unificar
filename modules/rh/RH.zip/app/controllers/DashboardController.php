<?php
/**
 * Controller do Dashboard de RH (Módulo 6)
 */
class DashboardController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        Auth::requireLogin();

        $today = date('Y-m-d');
        $currentMonth = (int)date('n');

        // Total de funcionários ativos
        $totalAtivos = (int)$this->db->query("SELECT COUNT(*) FROM employees WHERE status = 'ativo'")->fetchColumn();
        $totalAfastados = (int)$this->db->query("SELECT COUNT(*) FROM employees WHERE status = 'afastado'")->fetchColumn();
        $totalDesligados = (int)$this->db->query("SELECT COUNT(*) FROM employees WHERE status = 'desligado'")->fetchColumn();
        $totalFuncionarios = $totalAtivos + $totalAfastados + $totalDesligados;

        // Funcionários por departamento
        $deptStats = $this->db->query(
            "SELECT d.name, COUNT(e.id) as total
             FROM departments d
             LEFT JOIN employees e ON e.department_id = d.id AND e.status = 'ativo'
             GROUP BY d.id, d.name
             HAVING total > 0
             ORDER BY total DESC"
        )->fetchAll();

        // Vencimentos próximos (30 dias)
        $stmt = $this->db->prepare(
            "SELECT ex.*, e.full_name as employee_name
             FROM expirations ex
             JOIN employees e ON ex.employee_id = e.id
             WHERE ex.expiry_date BETWEEN ? AND DATE_ADD(?, INTERVAL 30 DAY)
             AND e.status = 'ativo'
             ORDER BY ex.expiry_date ASC
             LIMIT 10"
        );
        $stmt->execute([$today, $today]);
        $upcomingExpirations = $stmt->fetchAll();

        // Vencimentos vencidos
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM expirations ex
             JOIN employees e ON ex.employee_id = e.id
             WHERE ex.expiry_date < ? AND e.status = 'ativo'"
        );
        $stmt->execute([$today]);
        $expiredCount = (int)$stmt->fetchColumn();

        // Aniversariantes do mês
        $stmt = $this->db->prepare(
            "SELECT e.full_name, DAY(e.birth_date) as birth_day, d.name as department_name
             FROM employees e
             LEFT JOIN departments d ON e.department_id = d.id
             WHERE MONTH(e.birth_date) = ? AND e.status = 'ativo'
             ORDER BY DAY(e.birth_date) ASC
             LIMIT 10"
        );
        $stmt->execute([$currentMonth]);
        $birthdays = $stmt->fetchAll();

        // Compromissos de hoje
        $stmt = $this->db->prepare(
            "SELECT s.*, e.full_name as employee_name
             FROM schedules s
             LEFT JOIN employees e ON s.employee_id = e.id
             WHERE s.event_date = ?
             ORDER BY s.event_time ASC"
        );
        $stmt->execute([$today]);
        $todayEvents = $stmt->fetchAll();

        // Notificações não lidas
        $stmt = $this->db->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
        $stmt->execute([Session::userId()]);
        $unreadNotifications = (int)$stmt->fetchColumn();

        // Vagas abertas
        $openJobs = (int)$this->db->query("SELECT COUNT(*) FROM recruitment_jobs WHERE status = 'aberta'")->fetchColumn();

        // Últimas admissões (30 dias)
        $stmt = $this->db->prepare(
            "SELECT COUNT(*) FROM employees WHERE admission_date >= DATE_SUB(?, INTERVAL 30 DAY)"
        );
        $stmt->execute([$today]);
        $recentAdmissions = (int)$stmt->fetchColumn();

        $pageTitle = 'Dashboard';
        $page = 'dashboard';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/dashboard/index.php';
        require __DIR__ . '/../views/layout/footer.php';
    }
}
