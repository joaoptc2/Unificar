<?php
/**
 * Controller público para candidatos se inscreverem em vagas
 * Não requer autenticação
 */
class PublicRecruitmentController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    /**
     * Listar vagas abertas
     */
    public function index(): void
    {
        $jobs = $this->db->query(
            "SELECT rj.*, d.name as department_name
             FROM recruitment_jobs rj
             LEFT JOIN departments d ON rj.department_id = d.id
             WHERE rj.status = 'aberta'
             ORDER BY rj.created_at DESC"
        )->fetchAll();

        require __DIR__ . '/../views/public_recruitment/index.php';
    }

    /**
     * Formulário de inscrição
     */
    public function apply(): void
    {
        $jobId = Sanitize::int($_GET['job_id'] ?? 0);
        $stmt = $this->db->prepare(
            "SELECT rj.*, d.name as department_name
             FROM recruitment_jobs rj
             LEFT JOIN departments d ON rj.department_id = d.id
             WHERE rj.id = ? AND rj.status = 'aberta'"
        );
        $stmt->execute([$jobId]);
        $job = $stmt->fetch();

        if (!$job) {
            $error = 'Vaga não encontrada ou já encerrada.';
            require __DIR__ . '/../views/public_recruitment/index.php';
            return;
        }

        $success = Session::flash('success');
        $error = Session::flash('error');

        require __DIR__ . '/../views/public_recruitment/apply.php';
    }

    /**
     * Processar inscrição
     */
    public function submit(): void
    {
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            header('Location: index.php?page=public_recruitment');
            exit;
        }

        Csrf::check();

        $jobId    = Sanitize::int($_POST['job_id'] ?? 0);
        $fullName = Sanitize::post('full_name');
        $email    = Sanitize::email($_POST['email'] ?? '');
        $phone    = Sanitize::phone($_POST['phone'] ?? '');
        $cpf      = Sanitize::cpf($_POST['cpf'] ?? '');
        $area     = Sanitize::post('area');
        $experience = Sanitize::post('experience');

        if (empty($fullName) || empty($email)) {
            Session::flash('error', 'Nome e e-mail são obrigatórios.');
            header('Location: index.php?page=public_recruitment&action=apply&job_id=' . $jobId);
            exit;
        }

        // Upload de currículo
        $resumePath = null;
        if (!empty($_FILES['resume']['name'])) {
            $upload = Upload::handle('resume', 'resumes');
            if ($upload['success']) {
                $resumePath = $upload['path'];
            }
        }

        // Token de acesso para acompanhamento
        $accessToken = bin2hex(random_bytes(32));

        $stmt = $this->db->prepare(
            'INSERT INTO candidates (job_id, full_name, email, phone, cpf, area, experience, resume_path, access_token, status)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, "inscrito")'
        );
        $stmt->execute([$jobId, $fullName, $email, $phone, $cpf, $area, $experience, $resumePath, $accessToken]);

        Session::flash('success', 'Inscrição realizada com sucesso! Seu código de acompanhamento: ' . substr($accessToken, 0, 12));
        header('Location: index.php?page=public_recruitment&action=apply&job_id=' . $jobId);
        exit;
    }

    /**
     * Acompanhar status da candidatura
     */
    public function track(): void
    {
        $token = Sanitize::get('token');
        $candidate = null;
        $progress = [];

        if ($token) {
            $stmt = $this->db->prepare(
                'SELECT c.*, rj.title as job_title, rs.name as current_step_name
                 FROM candidates c
                 LEFT JOIN recruitment_jobs rj ON c.job_id = rj.id
                 LEFT JOIN recruitment_steps rs ON c.current_step_id = rs.id
                 WHERE c.access_token LIKE ?'
            );
            $stmt->execute([$token . '%']);
            $candidate = $stmt->fetch();

            if ($candidate) {
                $stmt = $this->db->prepare(
                    'SELECT cp.*, rs.name as step_name
                     FROM candidate_progress cp
                     JOIN recruitment_steps rs ON cp.step_id = rs.id
                     WHERE cp.candidate_id = ?
                     ORDER BY cp.created_at ASC'
                );
                $stmt->execute([$candidate['id']]);
                $progress = $stmt->fetchAll();
            }
        }

        require __DIR__ . '/../views/public_recruitment/track.php';
    }
}
