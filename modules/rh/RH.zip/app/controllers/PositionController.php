<?php
/**
 * Controller de Cargos (Administração)
 */
class PositionController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        Auth::requirePermission('positions', 'view');

        $positions = $this->db->query(
            "SELECT j.*, d.name as department_name,
                    (SELECT COUNT(*) FROM employees e WHERE e.job_position_id = j.id AND e.status = 'ativo') as employee_count
             FROM job_positions j
             LEFT JOIN departments d ON j.department_id = d.id
             ORDER BY j.title"
        )->fetchAll();

        $pageTitle = 'Cargos';
        $page = 'positions';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/positions/index.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function create(): void
    {
        Auth::requirePermission('positions', 'create');
        $position = null;
        $departments = $this->db->query('SELECT id, name FROM departments WHERE active = 1 ORDER BY name')->fetchAll();

        $pageTitle = 'Novo Cargo';
        $page = 'positions';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/positions/form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function store(): void
    {
        Auth::requirePermission('positions', 'create');
        Csrf::check();

        $stmt = $this->db->prepare('INSERT INTO job_positions (title, department_id, description, active) VALUES (?, ?, ?, ?)');
        $stmt->execute([
            Sanitize::post('title'),
            Sanitize::int($_POST['department_id'] ?? 0) ?: null,
            Sanitize::post('description'),
            isset($_POST['active']) ? 1 : 0
        ]);
        AuditLog::log('create', 'job_positions', (int)$this->db->lastInsertId());

        Session::flash('success', 'Cargo criado com sucesso.');
        header('Location: index.php?page=positions');
        exit;
    }

    public function edit(): void
    {
        Auth::requirePermission('positions', 'edit');

        $id = Sanitize::int($_GET['id'] ?? 0);
        $stmt = $this->db->prepare('SELECT * FROM job_positions WHERE id = ?');
        $stmt->execute([$id]);
        $position = $stmt->fetch();

        if (!$position) {
            Session::flash('error', 'Cargo não encontrado.');
            header('Location: index.php?page=positions');
            exit;
        }

        $departments = $this->db->query('SELECT id, name FROM departments WHERE active = 1 ORDER BY name')->fetchAll();

        $pageTitle = 'Editar Cargo';
        $page = 'positions';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/positions/form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function update(): void
    {
        Auth::requirePermission('positions', 'edit');
        Csrf::check();

        $id = Sanitize::int($_POST['id'] ?? 0);
        $stmt = $this->db->prepare('UPDATE job_positions SET title=?, department_id=?, description=?, active=? WHERE id=?');
        $stmt->execute([
            Sanitize::post('title'),
            Sanitize::int($_POST['department_id'] ?? 0) ?: null,
            Sanitize::post('description'),
            isset($_POST['active']) ? 1 : 0,
            $id
        ]);
        AuditLog::log('update', 'job_positions', $id);

        Session::flash('success', 'Cargo atualizado.');
        header('Location: index.php?page=positions');
        exit;
    }

    public function delete(): void
    {
        Auth::requirePermission('positions', 'delete');
        Csrf::check();

        $id = Sanitize::int($_POST['id'] ?? 0);

        $stmt = $this->db->prepare('SELECT COUNT(*) FROM employees WHERE job_position_id = ?');
        $stmt->execute([$id]);
        if ((int)$stmt->fetchColumn() > 0) {
            Session::flash('error', 'Não é possível excluir: existem funcionários vinculados.');
            header('Location: index.php?page=positions');
            exit;
        }

        $this->db->prepare('DELETE FROM job_positions WHERE id = ?')->execute([$id]);
        AuditLog::log('delete', 'job_positions', $id);

        Session::flash('success', 'Cargo excluído.');
        header('Location: index.php?page=positions');
        exit;
    }
}
