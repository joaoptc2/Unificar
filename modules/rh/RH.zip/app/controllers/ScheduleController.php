<?php
/**
 * Controller de Agenda e Compromissos (Módulo 4)
 */
class ScheduleController
{
    private PDO $db;

    public function __construct()
    {
        $this->db = Database::getInstance();
    }

    public function index(): void
    {
        Auth::requirePermission('schedules', 'view');

        $view = Sanitize::get('view', 'month'); // day, week, month
        $dateParam = Sanitize::get('date', date('Y-m-d'));

        try {
            $currentDate = new DateTime($dateParam);
        } catch (Exception $e) {
            $currentDate = new DateTime();
        }

        $year = (int)$currentDate->format('Y');
        $month = (int)$currentDate->format('m');
        $day = (int)$currentDate->format('d');

        // Calcular intervalo baseado na visualização
        if ($view === 'day') {
            $startDate = $currentDate->format('Y-m-d');
            $endDate = $currentDate->format('Y-m-d');
        } elseif ($view === 'week') {
            $dow = (int)$currentDate->format('w');
            $start = clone $currentDate;
            $start->modify("-{$dow} days");
            $end = clone $start;
            $end->modify('+6 days');
            $startDate = $start->format('Y-m-d');
            $endDate = $end->format('Y-m-d');
        } else {
            $startDate = sprintf('%04d-%02d-01', $year, $month);
            $endDate = date('Y-m-t', strtotime($startDate));
        }

        // Buscar eventos
        $stmt = $this->db->prepare(
            'SELECT s.*, e.full_name as employee_name
             FROM schedules s
             LEFT JOIN employees e ON s.employee_id = e.id
             WHERE s.event_date BETWEEN ? AND ?
             ORDER BY s.event_date ASC, s.event_time ASC'
        );
        $stmt->execute([$startDate, $endDate]);
        $events = $stmt->fetchAll();

        // Organizar eventos por data
        $eventsByDate = [];
        foreach ($events as $ev) {
            $eventsByDate[$ev['event_date']][] = $ev;
        }

        $employees = $this->db->query("SELECT id, full_name FROM employees WHERE status = 'ativo' ORDER BY full_name")->fetchAll();

        $pageTitle = 'Agenda';
        $page = 'schedules';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/schedules/index.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function create(): void
    {
        Auth::requirePermission('schedules', 'create');

        $employees = $this->db->query("SELECT id, full_name FROM employees WHERE status = 'ativo' ORDER BY full_name")->fetchAll();
        $schedule = null;

        $pageTitle = 'Novo Compromisso';
        $page = 'schedules';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/schedules/form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function store(): void
    {
        Auth::requirePermission('schedules', 'create');
        Csrf::check();

        $data = $this->getFormData();

        if (empty($data['title']) || empty($data['event_date'])) {
            Session::flash('error', 'Preencha os campos obrigatórios.');
            header('Location: index.php?page=schedules&action=create');
            exit;
        }

        $stmt = $this->db->prepare(
            'INSERT INTO schedules (employee_id, title, description, event_date, event_time, end_time, event_type, color, created_by)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $data['employee_id'] ?: null, $data['title'], $data['description'],
            $data['event_date'], $data['event_time'] ?: null, $data['end_time'] ?: null,
            $data['event_type'], $data['color'], Session::userId()
        ]);

        AuditLog::log('create', 'schedules', (int)$this->db->lastInsertId());

        Session::flash('success', 'Compromisso cadastrado com sucesso.');
        header('Location: index.php?page=schedules&date=' . $data['event_date']);
        exit;
    }

    public function edit(): void
    {
        Auth::requirePermission('schedules', 'edit');

        $id = Sanitize::int($_GET['id'] ?? 0);
        $stmt = $this->db->prepare('SELECT * FROM schedules WHERE id = ?');
        $stmt->execute([$id]);
        $schedule = $stmt->fetch();

        if (!$schedule) {
            Session::flash('error', 'Compromisso não encontrado.');
            header('Location: index.php?page=schedules');
            exit;
        }

        $employees = $this->db->query("SELECT id, full_name FROM employees WHERE status = 'ativo' ORDER BY full_name")->fetchAll();

        $pageTitle = 'Editar Compromisso';
        $page = 'schedules';
        require __DIR__ . '/../views/layout/header.php';
        require __DIR__ . '/../views/schedules/form.php';
        require __DIR__ . '/../views/layout/footer.php';
    }

    public function update(): void
    {
        Auth::requirePermission('schedules', 'edit');
        Csrf::check();

        $id = Sanitize::int($_POST['id'] ?? 0);
        $data = $this->getFormData();

        $stmt = $this->db->prepare(
            'UPDATE schedules SET employee_id=?, title=?, description=?, event_date=?, event_time=?, end_time=?, event_type=?, color=?
             WHERE id=?'
        );
        $stmt->execute([
            $data['employee_id'] ?: null, $data['title'], $data['description'],
            $data['event_date'], $data['event_time'] ?: null, $data['end_time'] ?: null,
            $data['event_type'], $data['color'], $id
        ]);

        AuditLog::log('update', 'schedules', $id);

        Session::flash('success', 'Compromisso atualizado.');
        header('Location: index.php?page=schedules&date=' . $data['event_date']);
        exit;
    }

    public function delete(): void
    {
        Auth::requirePermission('schedules', 'delete');
        Csrf::check();

        $id = Sanitize::int($_POST['id'] ?? 0);
        $this->db->prepare('DELETE FROM schedules WHERE id = ?')->execute([$id]);
        AuditLog::log('delete', 'schedules', $id);

        Session::flash('success', 'Compromisso excluído.');
        header('Location: index.php?page=schedules');
        exit;
    }

    private function getFormData(): array
    {
        return [
            'employee_id' => Sanitize::int($_POST['employee_id'] ?? 0),
            'title'       => Sanitize::post('title'),
            'description' => Sanitize::post('description'),
            'event_date'  => Sanitize::date($_POST['event_date'] ?? ''),
            'event_time'  => Sanitize::post('event_time'),
            'end_time'    => Sanitize::post('end_time'),
            'event_type'  => Sanitize::post('event_type') ?: 'compromisso',
            'color'       => Sanitize::post('color') ?: '#0d6efd',
        ];
    }
}
