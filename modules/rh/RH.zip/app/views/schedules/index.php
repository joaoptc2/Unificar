<?php
$prevMonth = (clone $currentDate)->modify('-1 month')->format('Y-m-d');
$nextMonth = (clone $currentDate)->modify('+1 month')->format('Y-m-d');
$todayStr = date('Y-m-d');
$monthNames = ['','Janeiro','Fevereiro','Março','Abril','Maio','Junho','Julho','Agosto','Setembro','Outubro','Novembro','Dezembro'];
$dayNames = ['Dom','Seg','Ter','Qua','Qui','Sex','Sáb'];
?>

<div class="page-header">
    <h1><i class="bi bi-calendar3 me-2"></i>Agenda</h1>
    <div class="d-flex gap-2">
        <?php if (Auth::can('schedules', 'create')): ?>
            <a href="index.php?page=schedules&action=create" class="btn btn-primary btn-sm">
                <i class="bi bi-plus-lg me-1"></i> Novo Compromisso
            </a>
        <?php endif; ?>
    </div>
</div>

<!-- Navegação do calendário -->
<div class="card border-0 shadow-sm mb-3">
    <div class="card-body py-2 d-flex justify-content-between align-items-center">
        <a href="index.php?page=schedules&view=<?= $view ?>&date=<?= $prevMonth ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-chevron-left"></i>
        </a>
        <h5 class="mb-0 fw-bold"><?= $monthNames[$month] ?> <?= $year ?></h5>
        <a href="index.php?page=schedules&view=<?= $view ?>&date=<?= $nextMonth ?>" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-chevron-right"></i>
        </a>
    </div>
</div>

<!-- Visualização por mês -->
<div class="card border-0 shadow-sm">
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-bordered mb-0">
                <thead class="table-light">
                    <tr>
                        <?php foreach ($dayNames as $dn): ?>
                            <th class="text-center small py-2"><?= $dn ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $firstDay = mktime(0, 0, 0, $month, 1, $year);
                    $daysInMonth = (int)date('t', $firstDay);
                    $startDow = (int)date('w', $firstDay);
                    $dayCounter = 1;
                    $rows = ceil(($daysInMonth + $startDow) / 7);

                    for ($row = 0; $row < $rows; $row++):
                    ?>
                        <tr>
                            <?php for ($col = 0; $col < 7; $col++):
                                $cellIndex = $row * 7 + $col;
                                if ($cellIndex < $startDow || $dayCounter > $daysInMonth):
                            ?>
                                <td class="calendar-day bg-light"></td>
                            <?php else:
                                $cellDate = sprintf('%04d-%02d-%02d', $year, $month, $dayCounter);
                                $isToday = $cellDate === $todayStr;
                                $dayEvents = $eventsByDate[$cellDate] ?? [];
                            ?>
                                <td class="calendar-day <?= $isToday ? 'today' : '' ?>">
                                    <div class="day-number <?= $isToday ? 'text-primary' : '' ?>"><?= $dayCounter ?></div>
                                    <?php foreach (array_slice($dayEvents, 0, 3) as $ev): ?>
                                        <div class="calendar-event" style="border-left-color: <?= Sanitize::e($ev['color']) ?>"
                                             title="<?= Sanitize::e($ev['title']) ?>"
                                             onclick="location.href='index.php?page=schedules&action=edit&id=<?= $ev['id'] ?>'">
                                            <?php if ($ev['event_time']): ?>
                                                <strong><?= substr($ev['event_time'], 0, 5) ?></strong>
                                            <?php endif; ?>
                                            <?= Sanitize::e($ev['title']) ?>
                                        </div>
                                    <?php endforeach; ?>
                                    <?php if (count($dayEvents) > 3): ?>
                                        <div class="text-muted small text-center">+<?= count($dayEvents) - 3 ?> mais</div>
                                    <?php endif; ?>
                                </td>
                            <?php
                                $dayCounter++;
                                endif;
                            endfor; ?>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Lista de eventos do mês -->
<div class="card border-0 shadow-sm mt-3">
    <div class="card-header bg-white fw-semibold">
        <i class="bi bi-list-ul me-1"></i> Compromissos de <?= $monthNames[$month] ?>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover mb-0">
                <thead class="table-light">
                    <tr><th>Data</th><th>Hora</th><th>Título</th><th>Funcionário</th><th>Tipo</th><th></th></tr>
                </thead>
                <tbody>
                    <?php
                    $allEvents = [];
                    foreach ($eventsByDate as $evts) { $allEvents = array_merge($allEvents, $evts); }
                    if (empty($allEvents)):
                    ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">Nenhum compromisso neste mês.</td></tr>
                    <?php else: foreach ($allEvents as $ev): ?>
                        <tr>
                            <td><?= Sanitize::formatDate($ev['event_date']) ?></td>
                            <td><?= $ev['event_time'] ? substr($ev['event_time'], 0, 5) : '-' ?></td>
                            <td><?= Sanitize::e($ev['title']) ?></td>
                            <td><?= Sanitize::e($ev['employee_name'] ?? '-') ?></td>
                            <td><span class="badge bg-info"><?= Sanitize::e(ucfirst($ev['event_type'])) ?></span></td>
                            <td>
                                <?php if (Auth::can('schedules', 'edit')): ?>
                                    <a href="index.php?page=schedules&action=edit&id=<?= $ev['id'] ?>" class="btn btn-outline-warning btn-action"><i class="bi bi-pencil"></i></a>
                                <?php endif; ?>
                                <?php if (Auth::can('schedules', 'delete')): ?>
                                    <form method="POST" action="index.php?page=schedules&action=delete" class="d-inline">
                                        <?= Csrf::field() ?>
                                        <input type="hidden" name="id" value="<?= $ev['id'] ?>">
                                        <button type="submit" class="btn btn-outline-danger btn-action" data-confirm="Excluir?"><i class="bi bi-trash"></i></button>
                                    </form>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
