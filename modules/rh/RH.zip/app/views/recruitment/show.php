<div class="page-header">
    <h1><i class="bi bi-kanban me-2"></i><?= Sanitize::e($job['title']) ?></h1>
    <div class="d-flex gap-2">
        <span class="badge <?= $job['status'] === 'aberta' ? 'bg-success' : 'bg-secondary' ?> fs-6">
            <?= ucfirst($job['status']) ?>
        </span>
        <?php if (Auth::can('recruitment', 'edit')): ?>
            <a href="index.php?page=recruitment&action=edit&id=<?= $job['id'] ?>" class="btn btn-outline-warning btn-sm">
                <i class="bi bi-pencil me-1"></i> Editar
            </a>
        <?php endif; ?>
        <a href="index.php?page=recruitment" class="btn btn-outline-secondary btn-sm">
            <i class="bi bi-arrow-left me-1"></i> Voltar
        </a>
    </div>
</div>

<!-- Detalhes da vaga -->
<div class="card border-0 shadow-sm mb-3">
    <div class="card-body">
        <div class="row">
            <div class="col-md-4"><small class="text-muted">Departamento</small><div><?= Sanitize::e($job['department_name'] ?? '-') ?></div></div>
            <div class="col-md-8">
                <?php if ($job['description']): ?>
                    <small class="text-muted">Descrição</small>
                    <div class="small"><?= nl2br(Sanitize::e($job['description'])) ?></div>
                <?php endif; ?>
            </div>
        </div>
        <?php if ($job['status'] === 'aberta'): ?>
            <div class="mt-2">
                <small class="text-muted">Link público para candidatos:</small>
                <code class="ms-1">index.php?page=public_recruitment&action=apply&job_id=<?= $job['id'] ?></code>
            </div>
        <?php endif; ?>
    </div>
</div>

<!-- Kanban Board -->
<div class="d-flex gap-3 overflow-auto pb-3">
    <!-- Coluna: Novos inscritos -->
    <div class="kanban-column flex-shrink-0">
        <div class="column-header d-flex justify-content-between">
            <span>Inscritos</span>
            <span class="badge bg-secondary"><?= count($newCandidates) ?></span>
        </div>
        <div class="p-2" style="min-height:200px;">
            <?php foreach ($newCandidates as $c): ?>
                <div class="kanban-card">
                    <div class="fw-semibold"><?= Sanitize::e($c['full_name']) ?></div>
                    <small class="text-muted"><?= Sanitize::e($c['email']) ?></small>
                    <?php if ($c['resume_path']): ?>
                        <div><a href="<?= ASSET_URL . Sanitize::e($c['resume_path']) ?>" target="_blank" class="small"><i class="bi bi-file-earmark-pdf me-1"></i>Currículo</a></div>
                    <?php endif; ?>
                    <?php if (Auth::can('recruitment', 'edit') && !empty($steps)): ?>
                        <form method="POST" action="index.php?page=recruitment&action=move_candidate" class="mt-2">
                            <?= Csrf::field() ?>
                            <input type="hidden" name="candidate_id" value="<?= $c['id'] ?>">
                            <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                            <select name="step_id" class="form-select form-select-sm mb-1">
                                <?php foreach ($steps as $s): ?>
                                    <option value="<?= $s['id'] ?>"><?= Sanitize::e($s['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button type="submit" class="btn btn-primary btn-sm w-100">Mover</button>
                        </form>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <!-- Colunas das etapas -->
    <?php foreach ($steps as $step): ?>
        <div class="kanban-column flex-shrink-0">
            <div class="column-header d-flex justify-content-between">
                <span><?= Sanitize::e($step['name']) ?></span>
                <span class="badge bg-secondary"><?= count($candidatesByStep[$step['id']] ?? []) ?></span>
            </div>
            <div class="p-2" style="min-height:200px;">
                <?php foreach ($candidatesByStep[$step['id']] ?? [] as $c): ?>
                    <div class="kanban-card">
                        <div class="fw-semibold"><?= Sanitize::e($c['full_name']) ?></div>
                        <small class="text-muted"><?= Sanitize::e($c['email']) ?></small>
                        <?php if ($c['resume_path']): ?>
                            <div><a href="<?= ASSET_URL . Sanitize::e($c['resume_path']) ?>" target="_blank" class="small"><i class="bi bi-file-earmark-pdf me-1"></i>Currículo</a></div>
                        <?php endif; ?>
                        <?php if (Auth::can('recruitment', 'edit')): ?>
                            <div class="mt-2 d-flex gap-1">
                                <!-- Mover para próxima etapa -->
                                <form method="POST" action="index.php?page=recruitment&action=move_candidate" class="flex-grow-1">
                                    <?= Csrf::field() ?>
                                    <input type="hidden" name="candidate_id" value="<?= $c['id'] ?>">
                                    <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                                    <select name="step_id" class="form-select form-select-sm mb-1">
                                        <?php foreach ($steps as $s): ?>
                                            <option value="<?= $s['id'] ?>" <?= $s['id'] == $step['id'] ? 'selected' : '' ?>><?= Sanitize::e($s['name']) ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <button type="submit" class="btn btn-outline-primary btn-sm w-100">Mover</button>
                                </form>
                            </div>
                            <div class="mt-1 d-flex gap-1">
                                <form method="POST" action="index.php?page=recruitment&action=evaluate_candidate" class="flex-grow-1">
                                    <?= Csrf::field() ?>
                                    <input type="hidden" name="candidate_id" value="<?= $c['id'] ?>">
                                    <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                                    <input type="hidden" name="candidate_status" value="aprovado">
                                    <input type="hidden" name="notes" value="Aprovado na etapa <?= Sanitize::e($step['name']) ?>">
                                    <button type="submit" class="btn btn-success btn-sm w-100"><i class="bi bi-check"></i> Aprovar</button>
                                </form>
                                <form method="POST" action="index.php?page=recruitment&action=evaluate_candidate">
                                    <?= Csrf::field() ?>
                                    <input type="hidden" name="candidate_id" value="<?= $c['id'] ?>">
                                    <input type="hidden" name="job_id" value="<?= $job['id'] ?>">
                                    <input type="hidden" name="candidate_status" value="reprovado">
                                    <input type="hidden" name="notes" value="Reprovado na etapa <?= Sanitize::e($step['name']) ?>">
                                    <button type="submit" class="btn btn-danger btn-sm" data-confirm="Reprovar candidato?"><i class="bi bi-x"></i></button>
                                </form>
                            </div>
                        <?php endif; ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endforeach; ?>
</div>
