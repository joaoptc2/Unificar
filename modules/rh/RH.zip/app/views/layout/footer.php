        </div><!-- /.container-fluid -->
    </main>

    <!-- Footer -->
    <footer class="main-footer text-center text-muted py-3">
        <small>RH Hospital &copy; <?= date('Y') ?> — Sistema de Gestão de Recursos Humanos</small>
    </footer>

    <!-- Scripts -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?= ASSET_URL ?>js/app.js"></script>
    <?php if (!empty($extraJs)): ?>
        <?php foreach ($extraJs as $js): ?>
            <script src="<?= $js ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>
