<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= Sanitize::e($pageTitle ?? 'RH Hospital') ?> - RH Hospital</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= ASSET_URL ?>css/style.css" rel="stylesheet">
    <?php if (!empty($extraCss)): ?>
        <?php foreach ($extraCss as $css): ?>
            <link href="<?= $css ?>" rel="stylesheet">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <!-- Navbar superior -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top shadow-sm">
        <div class="container-fluid">
            <a class="navbar-brand fw-bold" href="index.php?page=dashboard">
                <i class="bi bi-hospital me-1"></i> RH Hospital
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#sidebar">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="d-none d-lg-flex align-items-center ms-auto">
                <!-- Notificações -->
                <div class="dropdown me-3">
                    <a class="nav-link text-white position-relative" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-bell fs-5"></i>
                        <?php
                        $unreadCount = 0;
                        try {
                            $db = Database::getInstance();
                            $stmt = $db->prepare('SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0');
                            $stmt->execute([Session::userId()]);
                            $unreadCount = (int)$stmt->fetchColumn();
                        } catch (Exception $e) {}
                        ?>
                        <?php if ($unreadCount > 0): ?>
                            <span class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger" style="font-size:0.6rem;">
                                <?= $unreadCount > 99 ? '99+' : $unreadCount ?>
                            </span>
                        <?php endif; ?>
                    </a>
                    <div class="dropdown-menu dropdown-menu-end shadow" style="width:320px; max-height:400px; overflow-y:auto;">
                        <h6 class="dropdown-header">Notificações</h6>
                        <?php
                        try {
                            $stmt = $db->prepare('SELECT * FROM notifications WHERE user_id = ? ORDER BY created_at DESC LIMIT 10');
                            $stmt->execute([Session::userId()]);
                            $notifs = $stmt->fetchAll();
                            if (empty($notifs)):
                        ?>
                            <div class="px-3 py-2 text-muted small">Nenhuma notificação.</div>
                        <?php else: foreach ($notifs as $n): ?>
                            <a class="dropdown-item small <?= $n['is_read'] ? '' : 'fw-bold bg-light' ?>"
                               href="index.php?page=notifications&action=read&id=<?= $n['id'] ?>">
                                <div class="text-truncate"><?= Sanitize::e($n['title']) ?></div>
                                <small class="text-muted"><?= Sanitize::formatDateTime($n['created_at']) ?></small>
                            </a>
                        <?php endforeach; endif; } catch (Exception $e) {} ?>
                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item text-center small" href="index.php?page=notifications">Ver todas</a>
                    </div>
                </div>

                <!-- Utilizador -->
                <div class="dropdown">
                    <a class="nav-link text-white dropdown-toggle" href="#" data-bs-toggle="dropdown">
                        <i class="bi bi-person-circle me-1"></i>
                        <?= Sanitize::e(Session::userName()) ?>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end shadow">
                        <li><span class="dropdown-item-text small text-muted"><?= Sanitize::e(ucfirst(Session::userRole())) ?></span></li>
                        <li><hr class="dropdown-divider"></li>
                        <li><a class="dropdown-item text-danger" href="index.php?page=logout&action=logout"><i class="bi bi-box-arrow-right me-2"></i>Sair</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </nav>

    <!-- Sidebar -->
    <div class="offcanvas-lg offcanvas-start sidebar" tabindex="-1" id="sidebar">
        <div class="offcanvas-header d-lg-none">
            <h5 class="offcanvas-title">Menu</h5>
            <button type="button" class="btn-close" data-bs-dismiss="offcanvas" data-bs-target="#sidebar"></button>
        </div>
        <div class="offcanvas-body p-0">
            <nav class="sidebar-nav">
                <ul class="nav flex-column">
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'dashboard' ? 'active' : '' ?>" href="index.php?page=dashboard">
                            <i class="bi bi-speedometer2 me-2"></i> Dashboard
                        </a>
                    </li>

                    <?php if (Auth::can('employees', 'view')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'employees' ? 'active' : '' ?>" href="index.php?page=employees">
                            <i class="bi bi-people me-2"></i> Funcionários
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (Auth::can('expirations', 'view')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'expirations' ? 'active' : '' ?>" href="index.php?page=expirations">
                            <i class="bi bi-clock-history me-2"></i> Vencimentos
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (Auth::can('schedules', 'view')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'schedules' ? 'active' : '' ?>" href="index.php?page=schedules">
                            <i class="bi bi-calendar3 me-2"></i> Agenda
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (Auth::can('birthdays', 'view')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'birthdays' ? 'active' : '' ?>" href="index.php?page=birthdays">
                            <i class="bi bi-gift me-2"></i> Aniversariantes
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (Auth::can('recruitment', 'view')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'recruitment' ? 'active' : '' ?>" href="index.php?page=recruitment">
                            <i class="bi bi-briefcase me-2"></i> Processos Seletivos
                        </a>
                    </li>
                    <?php endif; ?>

                    <?php if (Auth::can('talent_pool', 'view')): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'talent_pool' ? 'active' : '' ?>" href="index.php?page=talent_pool">
                            <i class="bi bi-star me-2"></i> Banco de Talentos
                        </a>
                    </li>
                    <?php endif; ?>

                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'notifications' ? 'active' : '' ?>" href="index.php?page=notifications">
                            <i class="bi bi-bell me-2"></i> Notificações
                            <?php if ($unreadCount > 0): ?>
                                <span class="badge bg-danger ms-1"><?= $unreadCount ?></span>
                            <?php endif; ?>
                        </a>
                    </li>

                    <?php if (Auth::isAdmin()): ?>
                    <li class="nav-header mt-3 mb-1"><small class="text-muted fw-bold px-3">ADMINISTRAÇÃO</small></li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'users' ? 'active' : '' ?>" href="index.php?page=users">
                            <i class="bi bi-shield-lock me-2"></i> Utilizadores
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'departments' ? 'active' : '' ?>" href="index.php?page=departments">
                            <i class="bi bi-building me-2"></i> Departamentos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'positions' ? 'active' : '' ?>" href="index.php?page=positions">
                            <i class="bi bi-diagram-3 me-2"></i> Cargos
                        </a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link <?= ($page ?? '') === 'users' && ($action ?? '') === 'audit_log' ? 'active' : '' ?>" href="index.php?page=users&action=audit_log">
                            <i class="bi bi-journal-text me-2"></i> Log de Auditoria
                        </a>
                    </li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </div>

    <!-- Conteúdo principal -->
    <main class="main-content">
        <div class="container-fluid py-3">
            <!-- Flash messages -->
            <?php $flashError = Session::flash('error'); ?>
            <?php $flashSuccess = Session::flash('success'); ?>
            <?php if ($flashError): ?>
                <div class="alert alert-danger alert-dismissible fade show" role="alert">
                    <?= $flashError ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
            <?php if ($flashSuccess): ?>
                <div class="alert alert-success alert-dismissible fade show" role="alert">
                    <?= $flashSuccess ?>
                    <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
                </div>
            <?php endif; ?>
