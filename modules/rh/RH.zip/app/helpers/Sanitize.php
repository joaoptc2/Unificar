<?php
/**
 * Sanitização e validação de inputs
 */
class Sanitize
{
    /**
     * Sanitiza string para saída HTML (proteção XSS)
     */
    public static function html(?string $value): string
    {
        if ($value === null) return '';
        return htmlspecialchars($value, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    }

    /**
     * Alias para html()
     */
    public static function e(?string $value): string
    {
        return self::html($value);
    }

    /**
     * Sanitiza string de input
     */
    public static function string(?string $value): string
    {
        if ($value === null) return '';
        return trim(strip_tags($value));
    }

    /**
     * Sanitiza e-mail
     */
    public static function email(?string $value): string
    {
        return filter_var(trim($value ?? ''), FILTER_SANITIZE_EMAIL);
    }

    /**
     * Sanitiza inteiro
     */
    public static function int($value): int
    {
        return (int) filter_var($value, FILTER_SANITIZE_NUMBER_INT);
    }

    /**
     * Sanitiza CPF (apenas números)
     */
    public static function cpf(?string $value): string
    {
        return preg_replace('/[^0-9]/', '', $value ?? '');
    }

    /**
     * Formata CPF para exibição
     */
    public static function formatCpf(?string $cpf): string
    {
        $cpf = self::cpf($cpf);
        if (strlen($cpf) !== 11) return $cpf;
        return substr($cpf, 0, 3) . '.' . substr($cpf, 3, 3) . '.' . substr($cpf, 6, 3) . '-' . substr($cpf, 9, 2);
    }

    /**
     * Valida CPF
     */
    public static function isValidCpf(?string $cpf): bool
    {
        $cpf = self::cpf($cpf);
        if (strlen($cpf) !== 11 || preg_match('/^(\d)\1{10}$/', $cpf)) return false;

        for ($t = 9; $t < 11; $t++) {
            $sum = 0;
            for ($i = 0; $i < $t; $i++) {
                $sum += $cpf[$i] * (($t + 1) - $i);
            }
            $digit = ((10 * $sum) % 11) % 10;
            if ($cpf[$t] != $digit) return false;
        }
        return true;
    }

    /**
     * Sanitiza telefone
     */
    public static function phone(?string $value): string
    {
        return preg_replace('/[^0-9()\-\s+]/', '', $value ?? '');
    }

    /**
     * Sanitiza data
     */
    public static function date(?string $value): ?string
    {
        if (empty($value)) return null;
        $d = \DateTime::createFromFormat('Y-m-d', $value);
        if ($d && $d->format('Y-m-d') === $value) return $value;
        $d = \DateTime::createFromFormat('d/m/Y', $value);
        if ($d) return $d->format('Y-m-d');
        return null;
    }

    /**
     * Formata data para exibição (dd/mm/aaaa)
     */
    public static function formatDate(?string $date): string
    {
        if (empty($date)) return '-';
        $d = \DateTime::createFromFormat('Y-m-d', $date);
        return $d ? $d->format('d/m/Y') : $date;
    }

    /**
     * Formata data e hora para exibição
     */
    public static function formatDateTime(?string $datetime): string
    {
        if (empty($datetime)) return '-';
        $d = new \DateTime($datetime);
        return $d->format('d/m/Y H:i');
    }

    /**
     * Obtém valor do POST sanitizado
     */
    public static function post(string $key, $default = ''): string
    {
        return self::string($_POST[$key] ?? $default);
    }

    /**
     * Obtém valor do GET sanitizado
     */
    public static function get(string $key, $default = ''): string
    {
        return self::string($_GET[$key] ?? $default);
    }
}
