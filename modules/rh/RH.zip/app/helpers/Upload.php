<?php
/**
 * Upload seguro de arquivos
 * - Renomeia com hash
 * - Valida MIME type
 * - Limita tamanho
 * - Bloqueia execução
 */
class Upload
{
    private static array $allowedMimes = [
        'application/pdf',
        'image/jpeg',
        'image/png',
        'application/msword',
        'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'application/vnd.ms-excel',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    ];

    private static array $allowedExtensions = [
        'pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx', 'xls', 'xlsx',
    ];

    private static int $maxSize = 5242880; // 5MB

    /**
     * Processa upload de arquivo
     *
     * @param string $fieldName Nome do campo do formulário
     * @param string $subDir Subdiretório (employees, documents, resumes)
     * @return array ['success' => bool, 'path' => string, 'original_name' => string, 'size' => int, 'error' => string]
     */
    public static function handle(string $fieldName, string $subDir = 'documents'): array
    {
        $result = ['success' => false, 'path' => '', 'original_name' => '', 'size' => 0, 'error' => ''];

        if (!isset($_FILES[$fieldName]) || $_FILES[$fieldName]['error'] === UPLOAD_ERR_NO_FILE) {
            $result['error'] = 'Nenhum arquivo enviado.';
            return $result;
        }

        $file = $_FILES[$fieldName];

        // Verificar erros de upload
        if ($file['error'] !== UPLOAD_ERR_OK) {
            $result['error'] = self::getUploadError($file['error']);
            return $result;
        }

        // Verificar tamanho
        if ($file['size'] > self::$maxSize) {
            $result['error'] = 'Arquivo excede o tamanho máximo permitido (' . round(self::$maxSize / 1024 / 1024, 1) . 'MB).';
            return $result;
        }

        // Verificar extensão
        $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        if (!in_array($ext, self::$allowedExtensions)) {
            $result['error'] = 'Extensão de arquivo não permitida: .' . $ext;
            return $result;
        }

        // Verificar MIME type real
        $finfo = new finfo(FILEINFO_MIME_TYPE);
        $mimeType = $finfo->file($file['tmp_name']);
        if (!in_array($mimeType, self::$allowedMimes)) {
            $result['error'] = 'Tipo de arquivo não permitido: ' . $mimeType;
            return $result;
        }

        // Gerar nome seguro com hash
        $safeName = bin2hex(random_bytes(16)) . '_' . time() . '.' . $ext;

        // Definir diretório de destino
        $uploadBase = realpath(__DIR__ . '/../../public/uploads/') . '/';
        $destDir = $uploadBase . $subDir . '/';

        if (!is_dir($destDir)) {
            mkdir($destDir, 0755, true);
        }

        // Criar .htaccess para bloquear execução (segurança extra)
        $htaccess = $destDir . '.htaccess';
        if (!file_exists($htaccess)) {
            file_put_contents($htaccess, "Options -ExecCGI\nRemoveHandler .php .phtml .php3 .php4 .php5 .phps\nAddType text/plain .php .phtml .php3 .php4 .php5 .phps\n<FilesMatch \"\\.(php|phtml|php3|php4|php5|phps)$\">\n    Deny from all\n</FilesMatch>\n");
        }

        $destPath = $destDir . $safeName;

        if (!move_uploaded_file($file['tmp_name'], $destPath)) {
            $result['error'] = 'Erro ao mover o arquivo. Verifique as permissões do diretório.';
            return $result;
        }

        $result['success'] = true;
        $result['path'] = 'uploads/' . $subDir . '/' . $safeName;
        $result['original_name'] = $file['name'];
        $result['size'] = $file['size'];

        return $result;
    }

    /**
     * Remove arquivo do disco
     */
    public static function delete(?string $relativePath): bool
    {
        if (empty($relativePath)) return false;
        $fullPath = realpath(__DIR__ . '/../../public/') . '/' . $relativePath;
        if (file_exists($fullPath) && is_file($fullPath)) {
            return unlink($fullPath);
        }
        return false;
    }

    /**
     * Traduz código de erro de upload
     */
    private static function getUploadError(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE   => 'Arquivo excede o limite do servidor.',
            UPLOAD_ERR_FORM_SIZE  => 'Arquivo excede o limite do formulário.',
            UPLOAD_ERR_PARTIAL    => 'Upload incompleto.',
            UPLOAD_ERR_NO_TMP_DIR => 'Diretório temporário não encontrado.',
            UPLOAD_ERR_CANT_WRITE => 'Falha ao gravar arquivo no disco.',
            UPLOAD_ERR_EXTENSION  => 'Upload bloqueado por extensão do servidor.',
            default               => 'Erro desconhecido no upload.',
        };
    }
}
