<?php
/**
 * Autenticação e controle de acesso (RBAC)
 */
class Auth
{
    /**
     * Mapa de permissões por perfil
     * Formato: 'modulo' => ['ação1', 'ação2', ...]
     */
    private static array $permissions = [
        'admin' => [
            '*' => ['*'], // acesso total
        ],
        'rh' => [
            'dashboard'    => ['view'],
            'employees'    => ['view', 'create', 'edit', 'delete', 'export'],
            'documents'    => ['view', 'create', 'edit', 'delete'],
            'expirations'  => ['view', 'create', 'edit', 'delete', 'export'],
            'schedules'    => ['view', 'create', 'edit', 'delete'],
            'birthdays'    => ['view'],
            'recruitment'  => ['view', 'create', 'edit', 'delete'],
            'talent_pool'  => ['view', 'create', 'edit', 'delete', 'export'],
            'notifications'=> ['view', 'delete'],
            'certificates' => ['view', 'create', 'edit', 'delete'],
            'departments'  => ['view'],
            'positions'    => ['view'],
        ],
        'gestor' => [
            'dashboard'    => ['view'],
            'employees'    => ['view'],
            'documents'    => ['view'],
            'expirations'  => ['view'],
            'schedules'    => ['view', 'create', 'edit'],
            'birthdays'    => ['view'],
            'recruitment'  => ['view'],
            'talent_pool'  => ['view'],
            'notifications'=> ['view'],
            'certificates' => ['view'],
        ],
        'visualizador' => [
            'dashboard'    => ['view'],
            'employees'    => ['view'],
            'birthdays'    => ['view'],
            'notifications'=> ['view'],
        ],
    ];

    /**
     * Tenta autenticar o utilizador
     */
    public static function attempt(string $email, string $password): bool
    {
        $db = Database::getInstance();
        $stmt = $db->prepare('SELECT * FROM users WHERE email = ? AND active = 1 LIMIT 1');
        $stmt->execute([$email]);
        $user = $stmt->fetch();

        if (!$user || !password_verify($password, $user['password'])) {
            return false;
        }

        // Regenerar sessão ao fazer login
        session_regenerate_id(true);

        Session::set('user_id', (int)$user['id']);
        Session::set('user_name', $user['name']);
        Session::set('user_email', $user['email']);
        Session::set('user_role', $user['role']);
        Session::set('user_department_id', $user['department_id'] ?? null);
        Session::set('_created', time());

        // Atualizar último login
        $stmt = $db->prepare('UPDATE users SET last_login = NOW() WHERE id = ?');
        $stmt->execute([$user['id']]);

        AuditLog::log('login', 'users', $user['id']);

        return true;
    }

    /**
     * Encerra a sessão do utilizador
     */
    public static function logout(): void
    {
        if (Session::userId()) {
            AuditLog::log('logout', 'users', Session::userId());
        }
        Session::destroy();
    }

    /**
     * Exige que o utilizador esteja autenticado
     */
    public static function requireLogin(): void
    {
        if (!Session::isLoggedIn()) {
            Session::flash('error', 'Você precisa estar logado para acessar esta página.');
            header('Location: index.php?page=login');
            exit;
        }
    }

    /**
     * Verifica se o utilizador tem permissão para a ação
     */
    public static function can(string $module, string $action): bool
    {
        $role = Session::userRole();
        if (!$role) return false;

        // Admin tem acesso total
        if ($role === 'admin') return true;

        $perms = self::$permissions[$role] ?? [];

        if (!isset($perms[$module])) return false;

        return in_array('*', $perms[$module]) || in_array($action, $perms[$module]);
    }

    /**
     * Exige permissão ou aborta
     */
    public static function requirePermission(string $module, string $action): void
    {
        self::requireLogin();
        if (!self::can($module, $action)) {
            http_response_code(403);
            Session::flash('error', 'Você não tem permissão para acessar este recurso.');
            header('Location: index.php?page=dashboard');
            exit;
        }
    }

    /**
     * Verifica se o utilizador é admin
     */
    public static function isAdmin(): bool
    {
        return Session::userRole() === 'admin';
    }
}
