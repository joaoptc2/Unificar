<?php
/**
 * Envio de e-mails via SMTP nativo do PHP
 * Compatível com hospedagem compartilhada
 */
class Mailer
{
    /**
     * Envia e-mail usando a função mail() do PHP
     */
    public static function send(string $to, string $subject, string $htmlBody): bool
    {
        $config = require __DIR__ . '/../../config/app.php';

        if (!$config['mail_enabled']) {
            return false;
        }

        $from = $config['mail_from'];
        $fromName = $config['mail_from_name'];

        $headers = [
            'MIME-Version: 1.0',
            'Content-type: text/html; charset=utf-8',
            'From: ' . $fromName . ' <' . $from . '>',
            'Reply-To: ' . $from,
            'X-Mailer: PHP/' . phpversion(),
        ];

        return @mail($to, $subject, $htmlBody, implode("\r\n", $headers));
    }

    /**
     * Envia notificação de vencimento por e-mail
     */
    public static function sendExpiryAlert(string $to, string $employeeName, string $expiryTitle, string $expiryDate): bool
    {
        $subject = 'Alerta de Vencimento - ' . $expiryTitle;
        $body = '
        <html>
        <body style="font-family: Arial, sans-serif; color: #333;">
            <h2 style="color: #dc3545;">Alerta de Vencimento</h2>
            <p>O seguinte item está próximo do vencimento ou já venceu:</p>
            <table style="border-collapse: collapse; width: 100%;">
                <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Funcionário:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($employeeName) . '</td></tr>
                <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Item:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($expiryTitle) . '</td></tr>
                <tr><td style="padding: 8px; border: 1px solid #ddd;"><strong>Vencimento:</strong></td><td style="padding: 8px; border: 1px solid #ddd;">' . htmlspecialchars($expiryDate) . '</td></tr>
            </table>
            <p style="margin-top: 20px; color: #666; font-size: 12px;">Este é um e-mail automático do sistema RH Hospital.</p>
        </body>
        </html>';

        return self::send($to, $subject, $body);
    }
}
