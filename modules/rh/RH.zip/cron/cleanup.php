<?php
/**
 * CRON Job: Limpeza de dados antigos
 *
 * Configurar no cPanel/Hostinger:
 * Frequência: Semanalmente (domingo às 03:00)
 * Comando: php /home/usuario/public_html/cron/cleanup.php
 */

if (php_sapi_name() !== 'cli') {
    http_response_code(403);
    exit('Acesso negado.');
}

define('BASE_PATH', dirname(__DIR__));

require BASE_PATH . '/config/database.php';
require BASE_PATH . '/config/app.php';
require BASE_PATH . '/app/helpers/Database.php';

echo "[" . date('Y-m-d H:i:s') . "] Iniciando limpeza...\n";

try {
    $db = Database::getInstance();

    // 1. Limpar notificações lidas com mais de 90 dias
    $stmt = $db->prepare("DELETE FROM notifications WHERE is_read = 1 AND created_at < DATE_SUB(NOW(), INTERVAL 90 DAY)");
    $stmt->execute();
    echo "  Notificações antigas removidas: {$stmt->rowCount()}\n";

    // 2. Limpar logs de auditoria com mais de 365 dias
    $stmt = $db->prepare("DELETE FROM audit_log WHERE created_at < DATE_SUB(NOW(), INTERVAL 365 DAY)");
    $stmt->execute();
    echo "  Logs de auditoria antigos removidos: {$stmt->rowCount()}\n";

    // 3. Resetar flags de notificação para vencimentos renovados
    $stmt = $db->prepare(
        "UPDATE expirations SET notified_at = NULL, notified_expired_at = NULL
         WHERE expiry_date > CURDATE() AND (notified_at IS NOT NULL OR notified_expired_at IS NOT NULL)"
    );
    $stmt->execute();
    echo "  Flags de vencimento resetadas: {$stmt->rowCount()}\n";

    echo "[" . date('Y-m-d H:i:s') . "] Limpeza concluída.\n";

} catch (Exception $e) {
    echo "[ERRO] " . $e->getMessage() . "\n";
    exit(1);
}
